import 'package:flutter/material.dart';

const darkBackColor = Color(0xFF1d1d1d);
const orangeButtonColor = Color(0xFFf8b13c);

const dOrangeButtonColor = Color(0xFFf09345);
const whiteTextColor = Color(0xFFffffff);
const lightDarkColor60 = Color.fromRGBO(24, 26, 32, 0.6);
const splashScreenColor = Color(0xFF111111);
const loginblackColor = Color(0xFF111111);
const halfWhiteColor = Color(0xFFEDEDED);
const greyColor = Color.fromARGB(255, 115, 116, 116);
const fieldCOlor = Color(0xFF393532);
const opacityDarklightColor = Color(0xFF393532);
